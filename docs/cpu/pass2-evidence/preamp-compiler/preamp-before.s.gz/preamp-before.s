	.p2align	2
__RNvXs0_NtCsjEjWYJPWuKh_13openwurli_dsp16dk_preamp_legacyNtB5_8DkPreampNtNtB7_6preamp11PreampModel14process_sample:
	.cfi_startproc
	stp	d15, d14, [sp, #-160]!
	.cfi_def_cfa_offset 160
	stp	d13, d12, [sp, #16]
	stp	d11, d10, [sp, #32]
	stp	d9, d8, [sp, #48]
	stp	x28, x27, [sp, #64]
	stp	x26, x25, [sp, #80]
	stp	x24, x23, [sp, #96]
	stp	x22, x21, [sp, #112]
	stp	x20, x19, [sp, #128]
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	sub	sp, sp, #416
	mov	x19, x0
	add	x20, x0, #376
	ldr	d1, [x0, #2088]
	ldr	d20, [x0, #2904]
	ldr	d19, [x0, #2864]
	ldp	d18, d17, [x0, #104]
	ldp	d16, d7, [x0, #120]
	ldp	d6, d5, [x0, #136]
	ldp	d4, d3, [x0, #152]
	ldr	d2, [x0, #872]
	fmul	d21, d18, d2
	movi.2d	v2, #0000000000000000
	fadd	d21, d21, d2
	ldr	d22, [x0, #880]
	fmul	d22, d17, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #888]
	fmul	d22, d16, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #896]
	fmul	d22, d7, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #904]
	fmul	d22, d6, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #912]
	fmul	d22, d5, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #920]
	fmul	d22, d4, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #928]
	fmul	d22, d3, d22
	fadd	d22, d21, d22
	ldr	d23, [x0, #936]
	ldp	d21, d24, [x0, #168]
	fmul	d23, d21, d23
	fadd	d23, d22, d23
	ldr	d22, [x0, #1016]
	fmul	d22, d18, d22
	fadd	d22, d22, d2
	ldr	d25, [x0, #1024]
	fmul	d25, d17, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1032]
	fmul	d25, d16, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1040]
	fmul	d25, d7, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1048]
	fmul	d25, d6, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1056]
	fmul	d25, d5, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1064]
	fmul	d25, d4, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1072]
	fmul	d25, d3, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1080]
	fmul	d25, d21, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1088]
	fmul	d25, d18, d25
	fadd	d25, d25, d2
	ldr	d26, [x0, #1096]
	fmul	d26, d17, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1104]
	fmul	d26, d16, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1112]
	fmul	d26, d7, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1120]
	fmul	d26, d6, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1128]
	fmul	d26, d5, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1136]
	fmul	d26, d4, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1144]
	fmul	d26, d3, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1152]
	fmul	d26, d21, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1160]
	fmul	d26, d18, d26
	fadd	d26, d26, d2
	ldr	d27, [x0, #1168]
	fmul	d27, d17, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1176]
	fmul	d27, d16, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1184]
	fmul	d27, d7, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1192]
	fmul	d27, d6, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1200]
	fmul	d27, d5, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1208]
	fmul	d27, d4, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1216]
	fmul	d27, d3, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1224]
	fmul	d27, d21, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1232]
	fmul	d27, d18, d27
	fadd	d27, d27, d2
	ldr	d28, [x0, #1240]
	fmul	d28, d17, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1248]
	fmul	d28, d16, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1256]
	fmul	d28, d7, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1264]
	fmul	d28, d6, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1272]
	fmul	d28, d5, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1280]
	fmul	d28, d4, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1288]
	fmul	d28, d3, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1296]
	fmul	d28, d21, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1304]
	fmul	d28, d18, d28
	fadd	d28, d28, d2
	ldr	d29, [x0, #1312]
	fmul	d29, d17, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1320]
	fmul	d29, d16, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1328]
	fmul	d29, d7, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1336]
	fmul	d29, d6, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1344]
	fmul	d29, d5, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1352]
	fmul	d29, d4, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1360]
	fmul	d29, d3, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1368]
	fmul	d29, d21, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1376]
	fmul	d29, d18, d29
	fadd	d29, d29, d2
	ldr	d30, [x0, #1384]
	fmul	d30, d17, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1392]
	fmul	d30, d16, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1400]
	fmul	d30, d7, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1408]
	fmul	d30, d6, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1416]
	fmul	d30, d5, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1424]
	fmul	d30, d4, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1432]
	fmul	d30, d3, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1440]
	fmul	d30, d21, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1448]
	fmul	d30, d18, d30
	fadd	d30, d30, d2
	ldr	d31, [x0, #1456]
	fmul	d31, d17, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1464]
	fmul	d31, d16, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1472]
	fmul	d31, d7, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1480]
	fmul	d31, d6, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1488]
	fmul	d31, d5, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1496]
	fmul	d31, d4, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1504]
	fmul	d31, d3, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1512]
	fmul	d31, d21, d31
	fadd	d30, d30, d31
	fmul	d20, d20, d21
	fsub	d30, d30, d20
	mov	x8, #62714
	movk	x8, #54249, lsl #16
	movk	x8, #20391, lsl #32
	movk	x8, #16367, lsl #48
	fmov	d20, x8
	fmul	d0, d0, d20
	str	d0, [sp, #168]
	fmul	d0, d0, d19
	ldp	d20, d19, [x0, #88]
	fadd	d0, d0, d20
	stp	d20, d0, [sp, #152]
	fadd	d0, d0, d19
	fadd	d19, d23, d0
	ldr	d0, [x0, #944]
	fmul	d18, d18, d0
	ldr	d0, [x0, #952]
	fmul	d17, d17, d0
	ldr	d0, [x0, #2896]
	fadd	d18, d18, d2
	fadd	d17, d18, d17
	ldr	d18, [x0, #960]
	fmul	d16, d16, d18
	fadd	d16, d17, d16
	ldr	d17, [x0, #968]
	fmul	d7, d7, d17
	fadd	d7, d16, d7
	ldr	d16, [x0, #976]
	fmul	d6, d6, d16
	fadd	d6, d7, d6
	ldr	d7, [x0, #984]
	fmul	d5, d5, d7
	fadd	d5, d6, d5
	ldr	d6, [x0, #992]
	fmul	d4, d4, d6
	fadd	d4, d5, d4
	ldr	d5, [x0, #1000]
	fmul	d3, d3, d5
	fadd	d3, d4, d3
	ldr	d4, [x0, #1008]
	fmul	d4, d21, d4
	fadd	d3, d3, d4
	fadd	d3, d3, d24
	fsub	d4, d22, d24
	ldp	d6, d5, [x0, #184]
	fadd	d3, d3, d5
	fsub	d5, d19, d5
	fadd	d7, d25, d6
	fsub	d6, d27, d6
	ldr	d16, [x0, #200]
	fadd	d7, d7, d16
	fsub	d4, d4, d16
	ldr	d16, [x0, #1584]
	fadd	d20, d16, d5
	ldr	d5, [x0, #1592]
	fadd	d19, d5, d3
	ldr	d3, [x0, #1600]
	fadd	d18, d3, d4
	ldr	d3, [x0, #1608]
	fadd	d17, d3, d7
	ldr	d3, [x0, #1616]
	fadd	d16, d3, d26
	ldr	d3, [x0, #1624]
	fadd	d7, d3, d6
	ldr	d3, [x0, #1632]
	fadd	d6, d3, d28
	ldr	d3, [x0, #1640]
	fadd	d5, d3, d29
	ldr	d3, [x0, #1648]
	fadd	d4, d3, d30
	ldp	q3, q23, [x0, #224]
	ldur	q21, [x0, #232]
	add	x8, x0, #288
	add	x9, x0, #296
	ld1.d	{ v3 }[1], [x9]
	fmul.2d	v3, v3, v20[0]
	movi.2d	v22, #0000000000000000
	fadd.2d	v3, v3, v22
	add	x9, x0, #304
	ld1.d	{ v21 }[1], [x9]
	fmul.2d	v21, v21, v19[0]
	add	x9, x0, #312
	ldp	q24, q25, [x0, #256]
	fadd.2d	v3, v3, v21
	ldp	q21, q26, [x0, #320]
	ext.16b	v27, v23, v21, #8
	ld1.d	{ v23 }[1], [x9]
	fmul.2d	v23, v23, v18[0]
	fadd.2d	v3, v3, v23
	fmul.2d	v23, v27, v17[0]
	fadd.2d	v3, v3, v23
	ext.16b	v23, v24, v26, #8
	mov.d	v24[1], v21[1]
	fmul.2d	v21, v24, v16[0]
	fadd.2d	v3, v3, v21
	fmul.2d	v21, v23, v7[0]
	fadd.2d	v3, v3, v21
	ldp	q21, q23, [x0, #352]
	ext.16b	v24, v25, v21, #8
	mov.d	v25[1], v26[1]
	fmul.2d	v25, v25, v6[0]
	fadd.2d	v3, v3, v25
	fmul.2d	v24, v24, v5[0]
	fadd.2d	v3, v3, v24
	ld1.d	{ v21 }[0], [x8]
	fmul.2d	v21, v21, v4[0]
	fadd.2d	v3, v3, v21
	ldr	q21, [x20]
	add	x8, x0, #440
	ld1.d	{ v23 }[1], [x8]
	add	x8, x0, #432
	fmul.2d	v23, v23, v20[0]
	fadd.2d	v23, v23, v22
	add	x9, x0, #448
	ld1.d	{ v21 }[1], [x9]
	fmul.2d	v21, v21, v19[0]
	add	x9, x0, #456
	ldp	q24, q25, [x0, #384]
	ldr	q26, [x0, #416]
	fadd.2d	v21, v23, v21
	ldp	q23, q27, [x0, #464]
	ext.16b	v28, v24, v23, #8
	ld1.d	{ v24 }[1], [x9]
	fmul.2d	v24, v24, v18[0]
	fadd.2d	v21, v21, v24
	fmul.2d	v24, v28, v17[0]
	fadd.2d	v21, v21, v24
	ext.16b	v24, v25, v27, #8
	mov.d	v25[1], v23[1]
	fmul.2d	v23, v25, v16[0]
	fadd.2d	v21, v21, v23
	fmul.2d	v23, v24, v7[0]
	fadd.2d	v21, v21, v23
	ldp	q23, q24, [x0, #496]
	ext.16b	v25, v26, v23, #8
	mov.d	v26[1], v27[1]
	fmul.2d	v26, v26, v6[0]
	fadd.2d	v21, v21, v26
	fmul.2d	v25, v25, v5[0]
	fadd.2d	v21, v21, v25
	ld1.d	{ v23 }[0], [x8]
	fmul.2d	v23, v23, v4[0]
	fadd.2d	v21, v21, v23
	ldr	q23, [x20, #144]
	add	x8, x0, #584
	ld1.d	{ v24 }[1], [x8]
	add	x8, x0, #576
	fmul.2d	v24, v24, v20[0]
	fadd.2d	v22, v24, v22
	add	x9, x0, #592
	ld1.d	{ v23 }[1], [x9]
	fmul.2d	v23, v23, v19[0]
	add	x9, x0, #600
	ldp	q24, q25, [x0, #528]
	ldr	q26, [x0, #560]
	fadd.2d	v22, v22, v23
	ldp	q23, q27, [x0, #608]
	ext.16b	v28, v24, v23, #8
	ld1.d	{ v24 }[1], [x9]
	fmul.2d	v24, v24, v18[0]
	fadd.2d	v22, v22, v24
	fmul.2d	v24, v28, v17[0]
	fadd.2d	v22, v22, v24
	ext.16b	v24, v25, v27, #8
	mov.d	v25[1], v23[1]
	fmul.2d	v23, v25, v16[0]
	fadd.2d	v22, v22, v23
	fmul.2d	v23, v24, v7[0]
	fadd.2d	v22, v22, v23
	ldr	q23, [x0, #640]
	ext.16b	v24, v26, v23, #8
	mov.d	v26[1], v27[1]
	fmul.2d	v25, v26, v6[0]
	fadd.2d	v22, v22, v25
	fmul.2d	v24, v24, v5[0]
	fadd.2d	v22, v22, v24
	ld1.d	{ v23 }[0], [x8]
	fmul.2d	v23, v23, v4[0]
	fadd.2d	v22, v22, v23
	ldr	d23, [x0, #656]
	fmul	d23, d20, d23
	fadd	d23, d23, d2
	ldr	d24, [x0, #664]
	fmul	d24, d19, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #672]
	fmul	d24, d18, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #680]
	fmul	d24, d17, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #688]
	fmul	d24, d16, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #696]
	fmul	d24, d7, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #704]
	fmul	d24, d6, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #712]
	fmul	d24, d5, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #720]
	fmul	d24, d4, d24
	fadd	d23, d23, d24
	ldr	d24, [x0, #728]
	fmul	d24, d20, d24
	fadd	d24, d24, d2
	ldr	d25, [x0, #736]
	fmul	d25, d19, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #744]
	fmul	d25, d18, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #752]
	fmul	d25, d17, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #760]
	fmul	d25, d16, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #768]
	fmul	d25, d7, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #776]
	fmul	d25, d6, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #784]
	fmul	d25, d5, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #792]
	fmul	d25, d4, d25
	fadd	d24, d24, d25
	ldr	d25, [x0, #800]
	fmul	d20, d20, d25
	fadd	d2, d20, d2
	ldr	d20, [x0, #808]
	fmul	d19, d19, d20
	fadd	d2, d2, d19
	ldr	d19, [x0, #816]
	fmul	d18, d18, d19
	fadd	d2, d2, d18
	ldr	d18, [x0, #824]
	fmul	d17, d17, d18
	fadd	d2, d2, d17
	ldr	d17, [x0, #832]
	fmul	d16, d16, d17
	fadd	d2, d2, d16
	ldr	d16, [x0, #840]
	fmul	d7, d7, d16
	fadd	d2, d2, d7
	ldr	d7, [x0, #848]
	fmul	d6, d6, d7
	fadd	d2, d2, d6
	ldr	d6, [x0, #856]
	fmul	d5, d5, d6
	fadd	d2, d2, d5
	ldr	d5, [x0, #864]
	fmul	d4, d4, d5
	fadd	d2, d2, d4
	ldr	x8, [x0]
	cmp	x8, #1
	b.ne	LBB107_3
	ldr	d4, [x19, #72]
	fcmp	d4, d0
	b.ne	LBB107_3
	ldr	d17, [x19, #80]
	ldr	d1, [x19, #8]
	ldp	q19, q0, [x19, #16]
	ldr	q16, [x19, #48]
	ldr	d4, [x19, #64]
	ext.16b	v20, v0, v0, #8
	mov.16b	v25, v20
	mov.d	v25[0], v1[0]
	mov.d	v20[1], v4[0]
	b	LBB107_4
LBB107_3:
	add	x8, x19, #1520
	fmul	d1, d1, d0
	fmov	d4, #1.00000000
	fadd	d1, d1, d4
	fdiv	d17, d0, d1
	add	x9, x19, #1576
	ldr	q1, [x19, #2112]
	ldr	q4, [x19, #2096]
	fmul.2d	v4, v4, v17[0]
	ext.16b	v5, v1, v1, #8
	ldr	q6, [x19, #2128]
	ext.16b	v7, v6, v6, #8
	ldr	q16, [x20, #1152]
	fmul.2d	v5, v4, v5
	fsub.2d	v19, v16, v5
	ldr	q5, [x20, #1168]
	fmul.2d	v1, v4, v1
	ext.16b	v5, v5, v5, #8
	mov.16b	v16, v5
	ld1.d	{ v16 }[0], [x8]
	fsub.2d	v1, v16, v1
	ldr	q16, [x20, #1184]
	fmul.2d	v7, v4, v7
	fmul.2d	v4, v4, v6
	ld1.d	{ v5 }[1], [x9]
	fsub.2d	v20, v5, v4
	mov	w8, #1
	str	x8, [x19]
	str	d1, [x19, #8]
	ext.16b	v4, v1, v20, #8
	stp	q19, q4, [x19, #16]
	fsub.2d	v16, v16, v7
	str	q16, [x19, #48]
	add	x8, x19, #64
	st1.d	{ v20 }[1], [x8]
	mov	d4, v20[1]
	str	d0, [x19, #72]
	str	d17, [x19, #80]
	mov.16b	v25, v1
LBB107_4:
	ldr	d0, [x19, #2880]
	str	d0, [sp, #120]
	ldr	d0, [x19, #2872]
	str	d0, [sp, #24]
	str	q17, [sp, #128]
	fmul	d0, d17, d2
	ldr	q5, [x20, #1568]
	str	q5, [sp, #48]
	fmul.2d	v5, v5, v0[0]
	fsub.2d	v6, v3, v5
	ldr	q3, [x20, #1584]
	fmul.2d	v3, v3, v0[0]
	fsub.2d	v5, v21, v3
	ldr	q3, [x20, #1600]
	fmul.2d	v3, v3, v0[0]
	fsub.2d	v3, v22, v3
	stp	q5, q3, [sp, #64]
	ldr	d3, [x19, #1992]
	fmul	d3, d0, d3
	fsub	d7, d23, d3
	ldr	d3, [x19, #2000]
	fmul	d3, d0, d3
	fsub	d3, d24, d3
	str	q3, [sp]
	ldr	d3, [x19, #2008]
	fmul	d0, d0, d3
	fsub	d0, d2, d0
	stp	d7, d0, [sp, #104]
	zip1.2d	v0, v6, v5
	str	q6, [sp, #32]
	zip2.2d	v2, v6, v5
	fsub.2d	v3, v0, v2
	ldr	q18, [x19, #208]
	fneg.2d	v0, v19
	str	q0, [sp, #176]
	mov.16b	v0, v19
	mov.d	v0[0], v1[0]
	stp	q0, q3, [sp, #272]
	mov.d	v19[1], v25[1]
	mov.16b	v0, v20
	mov.d	v0[1], v16[1]
	str	q0, [sp, #256]
	mov.16b	v0, v16
	mov.d	v0[1], v4[0]
	str	q0, [sp, #240]
	mov	w22, #6
	fmov	d8, #-1.00000000
	mov	x8, #3689348814741910323
	movk	x8, #16363, lsl #48
	fmov	d9, x8
	mov	x23, #9667
	movk	x23, #40391, lsl #16
	movk	x23, #49618, lsl #32
	movk	x23, #16282, lsl #48
	fmov	d10, x23
	mov	x24, #11287
	movk	x24, #1493, lsl #16
	movk	x24, #52412, lsl #32
	movk	x24, #16288, lsl #48
	fmov	d11, x24
	mov	x21, #44841
	movk	x21, #61199, lsl #16
	movk	x21, #61651, lsl #32
	movk	x21, #15593, lsl #48
	fmov	d12, x21
	mov	x8, #42371
	movk	x8, #45276, lsl #16
	movk	x8, #3760, lsl #32
	movk	x8, #15649, lsl #48
	dup.2d	v1, x8
	mov	x8, #37266
	movk	x8, #8854, lsl #16
	movk	x8, #41028, lsl #32
	movk	x8, #15747, lsl #48
	dup.2d	v0, x8
	stp	q0, q1, [x29, #-240]
	mov	x25, #114349209288704
	movk	x25, #16534, lsl #48
	mov	x26, #54933
	movk	x26, #59430, lsl #16
	movk	x26, #11787, lsl #32
	movk	x26, #15889, lsl #48
	mov	x27, #49824
	movk	x27, #65259, lsl #16
	movk	x27, #18507, lsl #32
	movk	x27, #14772, lsl #48
	stur	q19, [x29, #-256]
	stp	q16, q20, [sp, #208]
	str	q25, [sp, #192]
LBB107_5:
	stur	q18, [x29, #-160]
	fcmp	d18, d8
	fcsel	d0, d8, d18, mi
	fcmp	d0, d9
	fcsel	d15, d9, d0, gt
	fdiv	d0, d15, d10
	bl	_exp
	stur	q0, [x29, #-176]
	fdiv	d0, d15, d11
	bl	_exp
	stur	q0, [x29, #-208]
	fadd	d0, d0, d8
	fmul	d14, d0, d12
	ldur	q0, [x29, #-160]
	mov	d15, v0[1]
	fcmp	d15, d8
	fcsel	d0, d8, d15, mi
	fcmp	d0, d9
	fcsel	d13, d9, d0, gt
	fdiv	d0, d13, d10
	bl	_exp
	stur	q0, [x29, #-192]
	fdiv	d0, d13, d11
	bl	_exp
	ldp	q22, q18, [x29, #-176]
	fmov.2d	v21, #1.00000000
	ldur	q1, [x29, #-192]
	mov.d	v22[1], v1[0]
	fmov.2d	v1, #-1.00000000
	fadd.2d	v1, v22, v1
	ldur	q20, [x29, #-224]
	fmul.2d	v2, v1, v20
	ldp	q19, q1, [x29, #-256]
	fmul.2d	v5, v22, v1
	fmov.2d	v1, #4.00000000
	fmul.2d	v1, v5, v1
	fadd.2d	v1, v1, v21
	fsqrt.2d	v3, v1
	fadd.2d	v1, v3, v21
	fmov.2d	v4, #0.50000000
	fmul.2d	v4, v1, v4
	fdiv.2d	v1, v2, v4
	fmov	d6, x25
	fdiv	d7, d2, d6
	fadd	d7, d14, d7
	mov	d16, v2[1]
	fdiv	d6, d16, d6
	fadd	d16, d0, d8
	fmul	d16, d16, d12
	fadd	d6, d16, d6
	ldp	q17, q16, [sp, #272]
	fsub.2d	v16, v18, v16
	fmul.2d	v17, v17, v1[0]
	fsub.2d	v16, v16, v17
	fmul.2d	v1, v19, v1[1]
	fsub.2d	v1, v16, v1
	ldr	q16, [sp, #256]
	fmul.2d	v7, v16, v7[0]
	fsub.2d	v1, v1, v7
	ldr	q7, [sp, #240]
	fmul.2d	v6, v7, v6[0]
	fsub.2d	v1, v1, v6
	fabs	d6, d1
	mov	d7, v1[1]
	fabs	d7, d7
	fmov	d16, x26
	fcmp	d6, d16
	fccmp	d7, d16, #0, mi
	b.mi	LBB107_9
	ldur	q6, [x29, #-208]
	mov.d	v6[1], v0[0]
	dup.2d	v0, x21
	fmul.2d	v0, v6, v0
	dup.2d	v6, x23
	fmul.2d	v7, v22, v20
	fdiv.2d	v5, v5, v6
	fmul.2d	v16, v4, v4
	dup.2d	v17, x24
	fdiv.2d	v0, v0, v17
	fdiv.2d	v6, v7, v6
	dup.2d	v7, x25
	fdiv.2d	v7, v6, v7
	fadd.2d	v7, v0, v7
	fmul.2d	v0, v6, v4
	fdiv.2d	v3, v5, v3
	fmul.2d	v2, v2, v3
	fsub.2d	v0, v0, v2
	fdiv.2d	v2, v0, v16
	ext.16b	v0, v2, v2, #8
	ext.16b	v3, v7, v7, #8
	ldp	q4, q25, [sp, #176]
	fmul.2d	v0, v0, v4
	ldp	q16, q20, [sp, #208]
	fmul.2d	v3, v3, v16
	fsub.2d	v0, v0, v3
	fmul.2d	v2, v2, v25
	fsub.2d	v2, v21, v2
	fmul.2d	v3, v7, v20
	fsub.2d	v2, v2, v3
	fmul.d	d3, d2, v2[1]
	fmul.d	d4, d0, v0[1]
	fabd	d5, d3, d4
	fmov	d6, x27
	fcmp	d5, d6
	b.mi	LBB107_9
	fsub	d3, d3, d4
	fmov	d4, #1.00000000
	fdiv	d3, d4, d3
	ext.16b	v2, v2, v2, #8
	fmul.2d	v2, v2, v1
	ext.16b	v1, v1, v1, #8
	fmul.2d	v0, v1, v0
	fsub.2d	v0, v2, v0
	fmul.2d	v0, v0, v3[0]
	fsub.2d	v18, v18, v0
	subs	w22, w22, #1
	b.ne	LBB107_5
	mov	d15, v18[1]
LBB107_9:
	stur	q18, [x29, #-160]
	fmov	d8, #-1.00000000
	fcmp	d18, d8
	fcsel	d0, d8, d18, mi
	mov	x8, #3689348814741910323
	movk	x8, #16363, lsl #48
	fmov	d9, x8
	fcmp	d0, d9
	fcsel	d10, d9, d0, gt
	mov	x8, #9667
	movk	x8, #40391, lsl #16
	movk	x8, #49618, lsl #32
	movk	x8, #16282, lsl #48
	fmov	d11, x8
	fdiv	d0, d10, d11
	bl	_exp
	stur	q0, [x29, #-192]
	mov	x8, #11287
	movk	x8, #1493, lsl #16
	movk	x8, #52412, lsl #32
	movk	x8, #16288, lsl #48
	fmov	d12, x8
	fdiv	d0, d10, d12
	bl	_exp
	stur	q0, [x29, #-176]
	fcmp	d15, d8
	fcsel	d0, d8, d15, mi
	fcmp	d0, d9
	fcsel	d8, d9, d0, gt
	fdiv	d0, d8, d11
	bl	_exp
	stur	q0, [x29, #-208]
	fdiv	d0, d8, d12
	bl	_exp
	ldr	d2, [x19, #1704]
	ldr	d4, [x19, #1776]
	add	x8, x19, #1712
	add	x9, x19, #1784
	ldp	q1, q3, [x29, #-208]
	mov.d	v3[1], v1[0]
	fmov.2d	v5, #-1.00000000
	fadd.2d	v1, v3, v5
	mov.16b	v6, v3
	ldur	q3, [x29, #-224]
	fmul.2d	v3, v1, v3
	ldur	q1, [x29, #-240]
	fmul.2d	v1, v6, v1
	fmov.2d	v6, #4.00000000
	fmul.2d	v1, v1, v6
	fmov.2d	v6, #1.00000000
	fadd.2d	v1, v1, v6
	fsqrt.2d	v1, v1
	fadd.2d	v1, v1, v6
	fmov.2d	v6, #0.50000000
	fmul.2d	v1, v1, v6
	ldr	q6, [x19, #2112]
	mov.16b	v7, v6
	ld1.d	{ v7 }[0], [x8]
	fdiv.2d	v1, v3, v1
	fmul.2d	v7, v1, v7
	ext.16b	v7, v7, v7, #8
	ld1.d	{ v6 }[1], [x9]
	fmul.2d	v6, v1, v6
	fadd.2d	v7, v6, v7
	ldr	q19, [sp, #128]
	ldr	q6, [sp]
	mov.d	v19[1], v6[0]
	ldr	q6, [x20, #1280]
	ldr	q16, [x19, #1728]
	fmul.2d	v6, v6, v1[0]
	fmul.2d	v16, v16, v1[1]
	fadd.2d	v16, v6, v16
	ldr	q6, [x20, #1296]
	ldr	q17, [x19, #1744]
	fmul.2d	v6, v6, v1[0]
	fmul.2d	v17, v17, v1[1]
	fadd.2d	v17, v6, v17
	ldr	q6, [x20, #1312]
	ldr	q18, [x19, #1760]
	fmul.2d	v6, v6, v1[0]
	fmul.2d	v18, v18, v1[1]
	fadd.2d	v18, v6, v18
	fmul	d2, d2, d1
	fmul.d	d4, d4, v1[1]
	fadd	d6, d2, d4
	ldr	d2, [x19, #1720]
	fmul	d2, d2, d1
	ldr	d4, [x19, #1792]
	fmul.d	d4, d4, v1[1]
	fadd	d4, d2, d4
	ldr	d2, [sp, #152]
	ldr	d20, [sp, #24]
	fmul	d2, d20, d2
	ldur	q20, [x29, #-176]
	mov.d	v20[1], v0[0]
	fadd.2d	v0, v20, v5
	dup.2d	v5, x21
	fmul.2d	v0, v0, v5
	mov	x8, #114349209288704
	movk	x8, #16534, lsl #48
	dup.2d	v5, x8
	add	x8, x19, #1856
	fdiv.2d	v3, v3, v5
	ldr	q5, [x19, #2128]
	fadd.2d	v0, v0, v3
	dup.2d	v3, v5[1]
	add	x9, x19, #1928
	ld1.d	{ v5 }[1], [x8]
	ld1.d	{ v3 }[1], [x9]
	fmul.2d	v5, v5, v0[0]
	fadd.2d	v5, v7, v5
	fmul.2d	v3, v3, v0[1]
	fadd.2d	v3, v5, v3
	fadd.2d	v5, v19, v3
	fmul.2d	v3, v19, v3
	ldr	q7, [x20, #1424]
	fmul.2d	v7, v7, v0[0]
	fadd.2d	v7, v16, v7
	ldr	q16, [x19, #1872]
	fmul.2d	v16, v16, v0[1]
	fadd.2d	v7, v7, v16
	ldp	q19, q16, [sp, #32]
	fadd.2d	v7, v19, v7
	fmul.2d	v16, v16, v3[0]
	fsub.2d	v7, v7, v16
	stur	q7, [x19, #104]
	ldr	q7, [x20, #1440]
	fmul.2d	v7, v7, v0[0]
	fadd.2d	v7, v17, v7
	ldr	q16, [x19, #1888]
	fmul.2d	v16, v16, v0[1]
	fadd.2d	v7, v7, v16
	ldr	q16, [sp, #64]
	fadd.2d	v7, v16, v7
	ldr	q16, [x20, #1584]
	fmul.2d	v16, v16, v3[0]
	fsub.2d	v7, v7, v16
	stur	q7, [x19, #120]
	ldr	q7, [x20, #1456]
	fmul.2d	v7, v7, v0[0]
	fadd.2d	v7, v18, v7
	ldr	q16, [x19, #1904]
	fmul.2d	v16, v16, v0[1]
	fadd.2d	v7, v7, v16
	ldr	q16, [sp, #80]
	fadd.2d	v7, v16, v7
	ldr	q16, [x20, #1600]
	fmul.2d	v16, v16, v3[0]
	fsub.2d	v7, v7, v16
	stur	q7, [x19, #136]
	ldr	d7, [x19, #1848]
	fmul	d7, d7, d0
	fadd	d6, d6, d7
	ldr	d7, [x19, #1920]
	fmul.d	d7, d7, v0[1]
	fadd	d6, d6, d7
	ldr	d7, [sp, #104]
	fadd	d6, d7, d6
	mov.d	v5[0], v6[0]
	ldr	q6, [x20, #1616]
	fmul.2d	v6, v6, v3[0]
	fsub.2d	v5, v5, v6
	ldr	d6, [x19, #1864]
	fmul	d6, d6, d0
	fadd	d4, d4, d6
	ldr	d6, [x19, #1936]
	fmul.d	d6, d6, v0[1]
	fadd	d4, d4, d6
	ldr	d6, [sp, #112]
	fadd	d4, d6, d4
	ldr	d6, [x19, #2008]
	fmul	d3, d6, d3
	fsub	d3, d4, d3
	str	d3, [x19, #168]
	ldr	d3, [x19, #104]
	ldr	d4, [sp, #168]
	fsub	d3, d4, d3
	ldr	d4, [sp, #120]
	fnmul	d3, d4, d3
	fsub	d2, d3, d2
	ldr	d3, [sp, #160]
	stp	d2, d3, [x19, #88]
	stp	q1, q0, [x19, #176]
	ldur	q0, [x29, #-160]
	stp	d0, d15, [x19, #208]
	ldr	d0, [x19, #2896]
	str	d0, [x19, #2904]
	stur	q5, [x19, #152]
	mov	d0, v5[1]
	fmov	x8, d0
	and	x8, x8, #0x7fffffffffffffff
	mov	x9, #9218868437227405311
	cmp	x8, x9
	b.le	LBB107_11
	mov	x0, x19
	bl	__RNvXs0_NtCsjEjWYJPWuKh_13openwurli_dsp16dk_preamp_legacyNtB5_8DkPreampNtNtB7_6preamp11PreampModel5reset
	movi.2d	v0, #0000000000000000
LBB107_11:
	add	sp, sp, #416
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	ldp	x20, x19, [sp, #128]
	ldp	x22, x21, [sp, #112]
	ldp	x24, x23, [sp, #96]
	ldp	x26, x25, [sp, #80]
	ldp	x28, x27, [sp, #64]
	ldp	d9, d8, [sp, #48]
	ldp	d11, d10, [sp, #32]
	ldp	d13, d12, [sp, #16]
	ldp	d15, d14, [sp], #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	.cfi_restore b15
	ret
	.cfi_endproc