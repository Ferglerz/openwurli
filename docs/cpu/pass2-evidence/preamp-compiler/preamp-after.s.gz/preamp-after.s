__RNvXs0_NtCs1m5hVyZa1ir_13openwurli_dsp16dk_preamp_legacyNtB5_8DkPreampNtNtB7_6preamp11PreampModel14process_sample:
	.cfi_startproc
	stp	d15, d14, [sp, #-160]!
	.cfi_def_cfa_offset 160
	stp	d13, d12, [sp, #16]
	stp	d11, d10, [sp, #32]
	stp	d9, d8, [sp, #48]
	stp	x28, x27, [sp, #64]
	stp	x26, x25, [sp, #80]
	stp	x24, x23, [sp, #96]
	stp	x22, x21, [sp, #112]
	stp	x20, x19, [sp, #128]
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	sub	sp, sp, #416
	mov	x19, x0
	add	x20, x0, #376
	ldr	d1, [x0, #2088]
	ldr	d20, [x0, #2904]
	ldr	d19, [x0, #2864]
	ldp	d18, d17, [x0, #104]
	ldp	d16, d7, [x0, #120]
	ldp	d6, d5, [x0, #136]
	ldp	d4, d3, [x0, #152]
	ldr	d2, [x0, #872]
	fmul	d21, d18, d2
	movi.2d	v2, #0000000000000000
	fadd	d21, d21, d2
	ldr	d22, [x0, #880]
	fmul	d22, d17, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #888]
	fmul	d22, d16, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #896]
	fmul	d22, d7, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #904]
	fmul	d22, d6, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #912]
	fmul	d22, d5, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #920]
	fmul	d22, d4, d22
	fadd	d21, d21, d22
	ldr	d22, [x0, #928]
	fmul	d22, d3, d22
	fadd	d22, d21, d22
	ldr	d23, [x0, #936]
	ldp	d21, d24, [x0, #168]
	fmul	d23, d21, d23
	fadd	d23, d22, d23
	ldr	d22, [x0, #1016]
	fmul	d22, d18, d22
	fadd	d22, d22, d2
	ldr	d25, [x0, #1024]
	fmul	d25, d17, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1032]
	fmul	d25, d16, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1040]
	fmul	d25, d7, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1048]
	fmul	d25, d6, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1056]
	fmul	d25, d5, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1064]
	fmul	d25, d4, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1072]
	fmul	d25, d3, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1080]
	fmul	d25, d21, d25
	fadd	d22, d22, d25
	ldr	d25, [x0, #1088]
	fmul	d25, d18, d25
	fadd	d25, d25, d2
	ldr	d26, [x0, #1096]
	fmul	d26, d17, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1104]
	fmul	d26, d16, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1112]
	fmul	d26, d7, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1120]
	fmul	d26, d6, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1128]
	fmul	d26, d5, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1136]
	fmul	d26, d4, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1144]
	fmul	d26, d3, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1152]
	fmul	d26, d21, d26
	fadd	d25, d25, d26
	ldr	d26, [x0, #1160]
	fmul	d26, d18, d26
	fadd	d26, d26, d2
	ldr	d27, [x0, #1168]
	fmul	d27, d17, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1176]
	fmul	d27, d16, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1184]
	fmul	d27, d7, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1192]
	fmul	d27, d6, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1200]
	fmul	d27, d5, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1208]
	fmul	d27, d4, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1216]
	fmul	d27, d3, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1224]
	fmul	d27, d21, d27
	fadd	d26, d26, d27
	ldr	d27, [x0, #1232]
	fmul	d27, d18, d27
	fadd	d27, d27, d2
	ldr	d28, [x0, #1240]
	fmul	d28, d17, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1248]
	fmul	d28, d16, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1256]
	fmul	d28, d7, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1264]
	fmul	d28, d6, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1272]
	fmul	d28, d5, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1280]
	fmul	d28, d4, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1288]
	fmul	d28, d3, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1296]
	fmul	d28, d21, d28
	fadd	d27, d27, d28
	ldr	d28, [x0, #1304]
	fmul	d28, d18, d28
	fadd	d28, d28, d2
	ldr	d29, [x0, #1312]
	fmul	d29, d17, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1320]
	fmul	d29, d16, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1328]
	fmul	d29, d7, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1336]
	fmul	d29, d6, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1344]
	fmul	d29, d5, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1352]
	fmul	d29, d4, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1360]
	fmul	d29, d3, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1368]
	fmul	d29, d21, d29
	fadd	d28, d28, d29
	ldr	d29, [x0, #1376]
	fmul	d29, d18, d29
	fadd	d29, d29, d2
	ldr	d30, [x0, #1384]
	fmul	d30, d17, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1392]
	fmul	d30, d16, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1400]
	fmul	d30, d7, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1408]
	fmul	d30, d6, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1416]
	fmul	d30, d5, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1424]
	fmul	d30, d4, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1432]
	fmul	d30, d3, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1440]
	fmul	d30, d21, d30
	fadd	d29, d29, d30
	ldr	d30, [x0, #1448]
	fmul	d30, d18, d30
	fadd	d30, d30, d2
	ldr	d31, [x0, #1456]
	fmul	d31, d17, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1464]
	fmul	d31, d16, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1472]
	fmul	d31, d7, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1480]
	fmul	d31, d6, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1488]
	fmul	d31, d5, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1496]
	fmul	d31, d4, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1504]
	fmul	d31, d3, d31
	fadd	d30, d30, d31
	ldr	d31, [x0, #1512]
	fmul	d31, d21, d31
	fadd	d30, d30, d31
	fmul	d20, d20, d21
	fsub	d30, d30, d20
	mov	x8, #62714
	movk	x8, #54249, lsl #16
	movk	x8, #20391, lsl #32
	movk	x8, #16367, lsl #48
	fmov	d20, x8
	fmul	d0, d0, d20
	str	d0, [sp, #168]
	fmul	d0, d0, d19
	ldp	d20, d19, [x0, #88]
	fadd	d0, d0, d20
	stp	d0, d20, [sp, #152]
	fadd	d0, d0, d19
	fadd	d19, d23, d0
	ldr	d0, [x0, #944]
	fmul	d18, d18, d0
	ldr	d0, [x0, #952]
	fmul	d17, d17, d0
	ldr	d0, [x0, #2896]
	fadd	d18, d18, d2
	fadd	d17, d18, d17
	ldr	d18, [x0, #960]
	fmul	d16, d16, d18
	fadd	d16, d17, d16
	ldr	d17, [x0, #968]
	fmul	d7, d7, d17
	fadd	d7, d16, d7
	ldr	d16, [x0, #976]
	fmul	d6, d6, d16
	fadd	d6, d7, d6
	ldr	d7, [x0, #984]
	fmul	d5, d5, d7
	fadd	d5, d6, d5
	ldr	d6, [x0, #992]
	fmul	d4, d4, d6
	fadd	d4, d5, d4
	ldr	d5, [x0, #1000]
	fmul	d3, d3, d5
	fadd	d3, d4, d3
	ldr	d4, [x0, #1008]
	fmul	d4, d21, d4
	fadd	d3, d3, d4
	fadd	d3, d3, d24
	fsub	d4, d22, d24
	ldp	d6, d5, [x0, #184]
	fadd	d3, d3, d5
	fsub	d5, d19, d5
	fadd	d7, d25, d6
	fsub	d6, d27, d6
	ldr	d16, [x0, #200]
	fadd	d7, d7, d16
	fsub	d4, d4, d16
	ldr	d16, [x0, #1584]
	fadd	d20, d16, d5
	ldr	d5, [x0, #1592]
	fadd	d19, d5, d3
	ldr	d3, [x0, #1600]
	fadd	d18, d3, d4
	ldr	d3, [x0, #1608]
	fadd	d17, d3, d7
	ldr	d3, [x0, #1616]
	fadd	d16, d3, d26
	ldr	d3, [x0, #1624]
	fadd	d7, d3, d6
	ldr	d3, [x0, #1632]
	fadd	d6, d3, d28
	ldr	d3, [x0, #1640]
	fadd	d5, d3, d29
	ldr	d3, [x0, #1648]
	fadd	d4, d3, d30
	ldp	q3, q23, [x0, #224]
	ldur	q21, [x0, #232]
	add	x8, x0, #288
	add	x9, x0, #296
	ld1.d	{ v3 }[1], [x9]
	fmul.2d	v3, v3, v20[0]
	movi.2d	v22, #0000000000000000
	fadd.2d	v3, v3, v22
	add	x9, x0, #304
	ld1.d	{ v21 }[1], [x9]
	fmul.2d	v21, v21, v19[0]
	add	x9, x0, #312
	ldp	q24, q25, [x0, #256]
	fadd.2d	v3, v3, v21
	ldp	q21, q26, [x0, #320]
	ext.16b	v27, v23, v21, #8
	ld1.d	{ v23 }[1], [x9]
	fmul.2d	v23, v23, v18[0]
	fadd.2d	v3, v3, v23
	fmul.2d	v23, v27, v17[0]
	fadd.2d	v3, v3, v23
	ext.16b	v23, v24, v26, #8
	mov.d	v24[1], v21[1]
	fmul.2d	v21, v24, v16[0]
	fadd.2d	v3, v3, v21
	fmul.2d	v21, v23, v7[0]
	fadd.2d	v3, v3, v21
	ldp	q21, q23, [x0, #352]
	ext.16b	v24, v25, v21, #8
	mov.d	v25[1], v26[1]
	fmul.2d	v25, v25, v6[0]
	fadd.2d	v3, v3, v25
	fmul.2d	v24, v24, v5[0]
	fadd.2d	v3, v3, v24
	ld1.d	{ v21 }[0], [x8]
	fmul.2d	v21, v21, v4[0]
	fadd.2d	v3, v3, v21
	ldr	q21, [x20]
	add	x8, x0, #440
	ld1.d	{ v23 }[1], [x8]
	add	x8, x0, #432
	fmul.2d	v23, v23, v20[0]
	fadd.2d	v23, v23, v22
	add	x9, x0, #448
	ld1.d	{ v21 }[1], [x9]
	fmul.2d	v21, v21, v19[0]
	add	x9, x0, #456
	ldp	q24, q25, [x0, #384]
	ldr	q26, [x0, #416]
	fadd.2d	v21, v23, v21
	ldp	q23, q27, [x0, #464]
	ext.16b	v28, v24, v23, #8
	ld1.d	{ v24 }[1], [x9]
	fmul.2d	v24, v24, v18[0]
	fadd.2d	v21, v21, v24
	fmul.2d	v24, v28, v17[0]
	fadd.2d	v21, v21, v24
	ext.16b	v24, v25, v27, #8
	mov.d	v25[1], v23[1]
	fmul.2d	v23, v25, v16[0]
	fadd.2d	v21, v21, v23
	fmul.2d	v23, v24, v7[0]
	fadd.2d	v21, v21, v23
	ldp	q23, q24, [x0, #496]
	ext.16b	v25, v26, v23, #8
	mov.d	v26[1], v27[1]
	fmul.2d	v26, v26, v6[0]
	fadd.2d	v21, v21, v26
	fmul.2d	v25, v25, v5[0]
	fadd.2d	v21, v21, v25
	ld1.d	{ v23 }[0], [x8]
	fmul.2d	v23, v23, v4[0]
	fadd.2d	v21, v21, v23
	ldr	q23, [x20, #144]
	add	x8, x0, #584
	ld1.d	{ v24 }[1], [x8]
	add	x8, x0, #576
	fmul.2d	v24, v24, v20[0]
	fadd.2d	v24, v24, v22
	add	x9, x0, #592
	ld1.d	{ v23 }[1], [x9]
	fmul.2d	v23, v23, v19[0]
	add	x9, x0, #600
	ldp	q25, q26, [x0, #528]
	fadd.2d	v23, v24, v23
	ldp	q24, q27, [x0, #608]
	ext.16b	v28, v25, v24, #8
	ld1.d	{ v25 }[1], [x9]
	fmul.2d	v25, v25, v18[0]
	fadd.2d	v23, v23, v25
	ldr	q25, [x0, #560]
	fmul.2d	v28, v28, v17[0]
	fadd.2d	v23, v23, v28
	ext.16b	v28, v26, v27, #8
	mov.d	v26[1], v24[1]
	fmul.2d	v24, v26, v16[0]
	fadd.2d	v23, v23, v24
	fmul.2d	v24, v28, v7[0]
	fadd.2d	v23, v23, v24
	ldp	q24, q26, [x0, #640]
	ext.16b	v28, v25, v24, #8
	mov.d	v25[1], v27[1]
	fmul.2d	v25, v25, v6[0]
	fadd.2d	v23, v23, v25
	fmul.2d	v25, v28, v5[0]
	fadd.2d	v23, v23, v25
	ld1.d	{ v24 }[0], [x8]
	fmul.2d	v24, v24, v4[0]
	fadd.2d	v23, v23, v24
	ldr	q24, [x20, #288]
	add	x8, x0, #728
	ld1.d	{ v26 }[1], [x8]
	add	x8, x0, #720
	fmul.2d	v25, v26, v20[0]
	fadd.2d	v22, v25, v22
	add	x9, x0, #736
	ld1.d	{ v24 }[1], [x9]
	fmul.2d	v24, v24, v19[0]
	add	x9, x0, #744
	ldp	q25, q26, [x0, #672]
	fadd.2d	v22, v22, v24
	ldp	q24, q27, [x0, #752]
	ext.16b	v28, v25, v24, #8
	ld1.d	{ v25 }[1], [x9]
	fmul.2d	v25, v25, v18[0]
	fadd.2d	v22, v22, v25
	ldr	q25, [x0, #704]
	fmul.2d	v28, v28, v17[0]
	fadd.2d	v22, v22, v28
	ext.16b	v28, v26, v27, #8
	mov.d	v26[1], v24[1]
	fmul.2d	v24, v26, v16[0]
	fadd.2d	v22, v22, v24
	fmul.2d	v24, v28, v7[0]
	fadd.2d	v22, v22, v24
	ldr	q24, [x0, #784]
	ext.16b	v26, v25, v24, #8
	mov.d	v25[1], v27[1]
	fmul.2d	v25, v25, v6[0]
	fadd.2d	v22, v22, v25
	fmul.2d	v25, v26, v5[0]
	fadd.2d	v22, v22, v25
	ld1.d	{ v24 }[0], [x8]
	fmul.2d	v24, v24, v4[0]
	fadd.2d	v22, v22, v24
	ldr	d24, [x0, #800]
	fmul	d20, d20, d24
	fadd	d2, d20, d2
	ldr	d20, [x0, #808]
	fmul	d19, d19, d20
	fadd	d2, d2, d19
	ldr	d19, [x0, #816]
	fmul	d18, d18, d19
	fadd	d2, d2, d18
	ldr	d18, [x0, #824]
	fmul	d17, d17, d18
	fadd	d2, d2, d17
	ldr	d17, [x0, #832]
	fmul	d16, d16, d17
	fadd	d2, d2, d16
	ldr	d16, [x0, #840]
	fmul	d7, d7, d16
	fadd	d2, d2, d7
	ldr	d7, [x0, #848]
	fmul	d6, d6, d7
	fadd	d2, d2, d6
	ldr	d6, [x0, #856]
	fmul	d5, d5, d6
	fadd	d2, d2, d5
	ldr	d5, [x0, #864]
	fmul	d4, d4, d5
	fadd	d2, d2, d4
	ldr	x8, [x0]
	cmp	x8, #1
	b.ne	LBB107_3
	ldr	d4, [x19, #72]
	fcmp	d4, d0
	b.ne	LBB107_3
	ldr	d17, [x19, #80]
	ldr	d1, [x19, #8]
	ldp	q20, q0, [x19, #16]
	ldr	q25, [x19, #48]
	ldr	d4, [x19, #64]
	ext.16b	v24, v0, v0, #8
	mov.16b	v26, v24
	mov.d	v26[0], v1[0]
	mov.d	v24[1], v4[0]
	b	LBB107_4
LBB107_3:
	add	x8, x19, #1520
	fmul	d1, d1, d0
	fmov	d4, #1.00000000
	fadd	d1, d1, d4
	fdiv	d17, d0, d1
	add	x9, x19, #1576
	ldr	q1, [x19, #2112]
	ldr	q4, [x19, #2096]
	fmul.2d	v4, v4, v17[0]
	ext.16b	v5, v1, v1, #8
	ldr	q6, [x19, #2128]
	ext.16b	v7, v6, v6, #8
	ldr	q16, [x20, #1152]
	fmul.2d	v5, v4, v5
	fsub.2d	v20, v16, v5
	ldr	q5, [x20, #1168]
	fmul.2d	v1, v4, v1
	ext.16b	v5, v5, v5, #8
	mov.16b	v16, v5
	ld1.d	{ v16 }[0], [x8]
	fsub.2d	v1, v16, v1
	ldr	q16, [x20, #1184]
	fmul.2d	v7, v4, v7
	fmul.2d	v4, v4, v6
	ld1.d	{ v5 }[1], [x9]
	fsub.2d	v24, v5, v4
	mov	w8, #1
	str	x8, [x19]
	str	d1, [x19, #8]
	ext.16b	v4, v1, v24, #8
	stp	q20, q4, [x19, #16]
	fsub.2d	v25, v16, v7
	str	q25, [x19, #48]
	add	x8, x19, #64
	st1.d	{ v24 }[1], [x8]
	mov	d4, v24[1]
	stp	d0, d17, [x19, #72]
	mov.16b	v26, v1
LBB107_4:
	ldr	d5, [x19, #2880]
	ldr	d0, [x19, #2872]
	stp	d0, d5, [sp, #136]
	str	q17, [sp, #112]
	fmul	d0, d17, d2
	ldr	q5, [x20, #1568]
	str	q5, [sp, #16]
	fmul.2d	v5, v5, v0[0]
	fsub.2d	v6, v3, v5
	ldr	q3, [x20, #1584]
	str	q3, [sp, #48]
	fmul.2d	v3, v3, v0[0]
	fsub.2d	v5, v21, v3
	ldr	q3, [x20, #1600]
	fmul.2d	v3, v3, v0[0]
	fsub.2d	v7, v23, v3
	ldr	q3, [x20, #1616]
	fmul.2d	v3, v3, v0[0]
	fsub.2d	v3, v22, v3
	stp	q7, q3, [sp, #64]
	ldr	d3, [x19, #2008]
	fmul	d0, d0, d3
	fsub	d0, d2, d0
	str	d0, [sp, #104]
	zip1.2d	v0, v6, v5
	str	q5, [sp, #32]
	str	q6, [sp]
	zip2.2d	v2, v6, v5
	fsub.2d	v3, v0, v2
	ldr	q19, [x19, #208]
	fneg.2d	v0, v20
	str	q0, [sp, #176]
	mov.16b	v0, v20
	mov.d	v0[0], v1[0]
	stp	q0, q3, [sp, #256]
	mov.d	v20[1], v26[1]
	mov.16b	v0, v24
	mov.d	v0[1], v25[1]
	str	q0, [sp, #240]
	mov.16b	v0, v25
	mov.d	v0[1], v4[0]
	str	q0, [sp, #224]
	mov	w21, #6
	fmov	d8, #-1.00000000
	mov	x8, #3689348814741910323
	movk	x8, #16363, lsl #48
	fmov	d9, x8
	mov	x22, #9667
	movk	x22, #40391, lsl #16
	movk	x22, #49618, lsl #32
	movk	x22, #16282, lsl #48
	fmov	d10, x22
	mov	x23, #11287
	movk	x23, #1493, lsl #16
	movk	x23, #52412, lsl #32
	movk	x23, #16288, lsl #48
	fmov	d11, x23
	mov	x24, #44841
	movk	x24, #61199, lsl #16
	movk	x24, #61651, lsl #32
	movk	x24, #15593, lsl #48
	fmov	d12, x24
	mov	x8, #42371
	movk	x8, #45276, lsl #16
	movk	x8, #3760, lsl #32
	movk	x8, #15649, lsl #48
	dup.2d	v23, x8
	mov	x8, #37266
	movk	x8, #8854, lsl #16
	movk	x8, #41028, lsl #32
	movk	x8, #15747, lsl #48
	dup.2d	v0, x8
	str	q0, [sp, #192]
	mov	x25, #114349209288704
	movk	x25, #16534, lsl #48
	mov	x26, #54933
	movk	x26, #59430, lsl #16
	movk	x26, #11787, lsl #32
	movk	x26, #15889, lsl #48
	mov	x27, #49824
	movk	x27, #65259, lsl #16
	movk	x27, #18507, lsl #32
	movk	x27, #14772, lsl #48
	stp	q24, q20, [x29, #-240]
	stur	q25, [x29, #-256]
	str	q26, [sp, #288]
	str	q23, [sp, #208]
LBB107_5:
	stur	q19, [x29, #-160]
	fcmp	d19, d8
	fcsel	d0, d8, d19, mi
	fcmp	d0, d9
	fcsel	d15, d9, d0, gt
	fdiv	d0, d15, d10
	bl	_exp
	stur	q0, [x29, #-176]
	fdiv	d0, d15, d11
	bl	_exp
	stur	q0, [x29, #-208]
	fadd	d0, d0, d8
	fmul	d14, d0, d12
	ldur	q0, [x29, #-160]
	mov	d15, v0[1]
	fcmp	d15, d8
	fcsel	d0, d8, d15, mi
	fcmp	d0, d9
	fcsel	d13, d9, d0, gt
	fdiv	d0, d13, d10
	bl	_exp
	stur	q0, [x29, #-192]
	fdiv	d0, d13, d11
	bl	_exp
	ldp	q18, q19, [x29, #-176]
	fmov.2d	v27, #1.00000000
	ldr	q23, [sp, #208]
	ldr	q26, [sp, #288]
	ldp	q25, q24, [x29, #-256]
	ldur	q20, [x29, #-224]
	ldur	q1, [x29, #-192]
	mov.d	v18[1], v1[0]
	fmov.2d	v1, #-1.00000000
	fadd.2d	v1, v18, v1
	fmul.2d	v2, v1, v23
	ldr	q1, [sp, #192]
	fmul.2d	v6, v18, v1
	fmov.2d	v1, #4.00000000
	fmul.2d	v1, v6, v1
	fadd.2d	v1, v1, v27
	fsqrt.2d	v4, v1
	fadd.2d	v1, v4, v27
	fmov.2d	v3, #0.50000000
	fmul.2d	v5, v1, v3
	fdiv.2d	v21, v2, v5
	fmov	d1, x25
	fdiv	d3, d2, d1
	fadd	d22, d14, d3
	mov	d3, v2[1]
	fdiv	d1, d3, d1
	fadd	d3, d0, d8
	fmul	d3, d3, d12
	fadd	d1, d3, d1
	ldp	q7, q3, [sp, #256]
	fsub.2d	v3, v19, v3
	fmul.2d	v7, v7, v21[0]
	fsub.2d	v3, v3, v7
	fmul.2d	v7, v20, v21[1]
	fsub.2d	v3, v3, v7
	ldr	q7, [sp, #240]
	fmul.2d	v7, v7, v22[0]
	fsub.2d	v3, v3, v7
	ldr	q7, [sp, #224]
	fmul.2d	v7, v7, v1[0]
	fsub.2d	v3, v3, v7
	fabs	d7, d3
	mov	d16, v3[1]
	fabs	d16, d16
	fmov	d17, x26
	fcmp	d7, d17
	fccmp	d16, d17, #0, mi
	b.mi	LBB107_9
	ldur	q7, [x29, #-208]
	mov.d	v7[1], v0[0]
	dup.2d	v0, x24
	fmul.2d	v0, v7, v0
	dup.2d	v7, x22
	fmul.2d	v16, v18, v23
	fdiv.2d	v6, v6, v7
	fmul.2d	v17, v5, v5
	dup.2d	v18, x23
	fdiv.2d	v0, v0, v18
	fdiv.2d	v7, v16, v7
	dup.2d	v16, x25
	fdiv.2d	v16, v7, v16
	fadd.2d	v16, v0, v16
	fmul.2d	v0, v7, v5
	fdiv.2d	v4, v6, v4
	fmul.2d	v2, v2, v4
	fsub.2d	v0, v0, v2
	fdiv.2d	v2, v0, v17
	ext.16b	v0, v2, v2, #8
	ext.16b	v4, v16, v16, #8
	ldr	q5, [sp, #176]
	fmul.2d	v0, v0, v5
	fmul.2d	v4, v4, v25
	fsub.2d	v0, v0, v4
	fmul.2d	v2, v2, v26
	fsub.2d	v2, v27, v2
	fmul.2d	v4, v16, v24
	fsub.2d	v2, v2, v4
	fmul.d	d4, d2, v2[1]
	fmul.d	d5, d0, v0[1]
	fabd	d6, d4, d5
	fmov	d7, x27
	fcmp	d6, d7
	b.mi	LBB107_9
	fsub	d1, d4, d5
	fmov	d4, #1.00000000
	fdiv	d1, d4, d1
	ext.16b	v2, v2, v2, #8
	fmul.2d	v2, v2, v3
	ext.16b	v3, v3, v3, #8
	fmul.2d	v0, v3, v0
	fsub.2d	v0, v2, v0
	fmul.2d	v0, v0, v1[0]
	fsub.2d	v19, v19, v0
	subs	w21, w21, #1
	b.ne	LBB107_5
	fmov	d9, #-1.00000000
	fcmp	d19, d9
	fcsel	d0, d9, d19, mi
	mov	x8, #3689348814741910323
	movk	x8, #16363, lsl #48
	fmov	d10, x8
	fcmp	d0, d10
	fcsel	d11, d10, d0, gt
	mov	x8, #9667
	movk	x8, #40391, lsl #16
	movk	x8, #49618, lsl #32
	movk	x8, #16282, lsl #48
	fmov	d0, x8
	stur	d0, [x29, #-176]
	fdiv	d0, d11, d0
	stur	q19, [x29, #-160]
	bl	_exp
	mov.16b	v8, v0
	mov	x8, #11287
	movk	x8, #1493, lsl #16
	movk	x8, #52412, lsl #32
	movk	x8, #16288, lsl #48
	fmov	d0, x8
	stur	d0, [x29, #-192]
	fdiv	d0, d11, d0
	bl	_exp
	fadd	d1, d8, d9
	mov	x8, #42371
	movk	x8, #45276, lsl #16
	movk	x8, #3760, lsl #32
	movk	x8, #15649, lsl #48
	fmov	d11, x8
	fmul	d1, d1, d11
	mov	x8, #37266
	movk	x8, #8854, lsl #16
	movk	x8, #41028, lsl #32
	movk	x8, #15747, lsl #48
	fmov	d14, x8
	fmul	d2, d8, d14
	fmov	d3, #4.00000000
	fmul	d2, d2, d3
	fmov	d3, #1.00000000
	fadd	d2, d2, d3
	fsqrt	d2, d2
	fadd	d2, d2, d3
	fmov	d3, #0.50000000
	fmul	d2, d2, d3
	fdiv	d2, d1, d2
	mov	x8, #114349209288704
	movk	x8, #16534, lsl #48
	fmov	d12, x8
	fdiv	d1, d1, d12
	fadd	d0, d0, d9
	mov	x8, #44841
	movk	x8, #61199, lsl #16
	movk	x8, #61651, lsl #32
	movk	x8, #15593, lsl #48
	fmov	d13, x8
	fmul	d0, d0, d13
	fadd	d0, d0, d1
	stp	q0, q2, [x29, #-224]
	ldur	q0, [x29, #-160]
	mov	d15, v0[1]
	fcmp	d15, d9
	fcsel	d0, d9, d15, mi
	fcmp	d0, d10
	fcsel	d10, d10, d0, gt
	ldur	d0, [x29, #-176]
	fdiv	d0, d10, d0
	bl	_exp
	mov.16b	v8, v0
	ldur	d0, [x29, #-192]
	fdiv	d0, d10, d0
	bl	_exp
	ldp	q22, q21, [x29, #-224]
	ldur	q19, [x29, #-160]
	fadd	d1, d8, d9
	fmul	d1, d1, d11
	fmul	d2, d8, d14
	fmov	d3, #4.00000000
	fmul	d2, d2, d3
	fmov	d3, #1.00000000
	fadd	d2, d2, d3
	fsqrt	d2, d2
	fadd	d2, d2, d3
	fmov	d3, #0.50000000
	fmul	d2, d2, d3
	fdiv	d2, d1, d2
	fdiv	d1, d1, d12
	fadd	d0, d0, d9
	fmul	d0, d0, d13
	fadd	d1, d0, d1
	b	LBB107_10
LBB107_9:
	mov	d2, v21[1]
LBB107_10:
	ldr	q4, [sp, #112]
	ldr	d0, [x19, #2112]
	fmul	d0, d21, d0
	ldr	d3, [x19, #2120]
	fmul	d3, d2, d3
	fadd	d0, d0, d3
	ldr	d3, [x19, #2128]
	fmul	d3, d22, d3
	fadd	d0, d0, d3
	ldr	d3, [x19, #2136]
	fmul	d3, d1, d3
	fadd	d0, d0, d3
	fmul	d0, d4, d0
	ldr	q3, [x20, #1280]
	fmul.2d	v3, v3, v21[0]
	ldr	q4, [x19, #1728]
	fmul.2d	v4, v4, v2[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x20, #1424]
	fmul.2d	v4, v4, v22[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x19, #1872]
	fmul.2d	v4, v4, v1[0]
	fadd.2d	v3, v3, v4
	ldp	q5, q4, [sp]
	fadd.2d	v3, v5, v3
	fmul.2d	v4, v4, v0[0]
	fsub.2d	v3, v3, v4
	stur	q3, [x19, #104]
	ldr	q3, [x20, #1296]
	fmul.2d	v3, v3, v21[0]
	ldr	q4, [x19, #1744]
	fmul.2d	v4, v4, v2[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x20, #1440]
	fmul.2d	v4, v4, v22[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x19, #1888]
	fmul.2d	v4, v4, v1[0]
	fadd.2d	v3, v3, v4
	ldp	q5, q4, [sp, #32]
	fadd.2d	v3, v5, v3
	fmul.2d	v4, v4, v0[0]
	fsub.2d	v3, v3, v4
	stur	q3, [x19, #120]
	ldr	q3, [x20, #1312]
	fmul.2d	v3, v3, v21[0]
	ldr	q4, [x19, #1760]
	fmul.2d	v4, v4, v2[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x20, #1456]
	fmul.2d	v4, v4, v22[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x19, #1904]
	fmul.2d	v4, v4, v1[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [sp, #64]
	fadd.2d	v3, v4, v3
	ldr	q4, [x20, #1600]
	fmul.2d	v4, v4, v0[0]
	fsub.2d	v3, v3, v4
	stur	q3, [x19, #136]
	ldr	q3, [x20, #1328]
	fmul.2d	v3, v3, v21[0]
	ldr	q4, [x19, #1776]
	fmul.2d	v4, v4, v2[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x20, #1472]
	fmul.2d	v4, v4, v22[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [x19, #1920]
	fmul.2d	v4, v4, v1[0]
	fadd.2d	v3, v3, v4
	ldr	q4, [sp, #80]
	fadd.2d	v3, v4, v3
	ldr	q4, [x20, #1616]
	fmul.2d	v4, v4, v0[0]
	fsub.2d	v3, v3, v4
	stur	q3, [x19, #152]
	ldr	d4, [x19, #1720]
	fmul	d4, d21, d4
	ldr	d5, [x19, #1792]
	fmul	d5, d2, d5
	fadd	d4, d4, d5
	ldr	d5, [x19, #1864]
	fmul	d5, d22, d5
	fadd	d4, d4, d5
	ldr	d5, [x19, #1936]
	fmul	d5, d1, d5
	fadd	d4, d4, d5
	ldr	d5, [sp, #104]
	fadd	d4, d5, d4
	ldr	d5, [x19, #2008]
	fmul	d0, d0, d5
	fsub	d0, d4, d0
	ldr	d4, [x19, #104]
	ldr	d5, [sp, #168]
	fsub	d4, d5, d4
	ldp	d6, d5, [sp, #136]
	fnmul	d4, d5, d4
	ldr	d5, [sp, #160]
	fmul	d5, d6, d5
	fsub	d4, d4, d5
	ldr	d5, [sp, #152]
	stp	d4, d5, [x19, #88]
	stp	d0, d21, [x19, #168]
	stp	d2, d22, [x19, #184]
	stp	d1, d19, [x19, #200]
	str	d15, [x19, #216]
	ldr	d0, [x19, #2896]
	str	d0, [x19, #2904]
	mov	d0, v3[1]
	fmov	x8, d0
	and	x8, x8, #0x7fffffffffffffff
	mov	x9, #9218868437227405311
	cmp	x8, x9
	b.le	LBB107_12
	mov	x0, x19
	bl	__RNvXs0_NtCs1m5hVyZa1ir_13openwurli_dsp16dk_preamp_legacyNtB5_8DkPreampNtNtB7_6preamp11PreampModel5reset
	movi.2d	v0, #0000000000000000
LBB107_12:
	add	sp, sp, #416
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	ldp	x20, x19, [sp, #128]
	ldp	x22, x21, [sp, #112]
	ldp	x24, x23, [sp, #96]
	ldp	x26, x25, [sp, #80]
	ldp	x28, x27, [sp, #64]
	ldp	d9, d8, [sp, #48]
	ldp	d11, d10, [sp, #32]
	ldp	d13, d12, [sp, #16]
	ldp	d15, d14, [sp], #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	.cfi_restore b15
	ret
	.cfi_endproc