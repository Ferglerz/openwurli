# Pass 2 circuit studies

Base: `fd4f603` (shipping native DSP). Both candidates remain feature gated and
were not timed or promoted by this agent.

## Preamp final-current reuse

Feature: `cpu-study-preamp-reuse`. Applies only to the legacy hand-written
preamp, not the melange Heavy preamp.

Release compiler proof: `compiler.json`, `preamp-before.ll` and
`preamp-before.s`. Original LLVM IR evaluates four exponentials inside the NR
loop (lines 844, 846, 855, 857); its successful-convergence branch at line 902
jumps directly into final evaluation at lines 915, 917, 923, 925, although Vbe
has not changed. Corresponding ARM64 assembly has four `bl _exp` calls at
679/682/693/696 and four more at 807/815/822/825. This was real generated work,
not merely duplicate source expressions that LLVM had already eliminated.

Candidate reuses the exact collector/base currents on convergence and singular-
determinant exits, both before any voltage update. Exhausting six iterations
still evaluates the final updated Vbe exactly as before. No iteration count,
convergence tolerance, derivative, clamp or current expression changed.
The false const-generic specialization retains the original reevaluation path
for focused source-level comparison without duplicating physical equations.

After compiler proof: `preamp-after.ll` branches from convergence at line 875
to `bb84.i.loopexit`, reusing loop currents. The four final exponential calls
at lines 884, 886, 906, 908 live in `bb85.i`, reached only from the exhausted
iteration path (`bb50.i`). `preamp-after.s` is the corresponding release assembly.

Focused test `final_current_reuse_matches_original_solver_trajectory` passed:
12,288 samples across 44.1/88.2/96 kHz, settled silence, small-signal, moderate
and severe overdrive, LDR changes and reset. It compares output and every node
voltage bitwise against original final reevaluation.

## Zero-depth LDR map skip

Feature: `cpu-study-tremolo-zero`. Shared by Fast and Heavy engines.

At exactly zero depth, the LDR-side divider branch is grounded. The candidate
advances the oscillator and CdS envelope as before, but skips the powf/exp
resistance map while that resistance is inaudible. `set_depth` refreshes the
native analytical mapping on zero-to-positive transition before exposing the
branch, including an immediate `current_resistance` query. Nonzero depth uses
the unchanged native function. Reset initializes the same state as before.

Focused test `zero_depth_skip_preserves_timing_reset_and_immediate_resistance`
passed at 44.1/96 kHz: 4,096 samples with response multiplier 0.5, zero/nonzero
and tiny-positive automation, reset, immediate setter queries, and bitwise
oscillator-envelope/output comparison against eagerly refreshed native mapping.

Checks: `cargo check -p openwurli-dsp --features
cpu-study-preamp-reuse,cpu-study-tremolo-zero`; each focused test individually;
release compiler emission with both candidate features. No full suite and no
CPU timing. Full engine pre/post proof and parent-scheduled timing remain gates.

## Heavy preamp shared matrix rebuild

Feature: `cpu-study-heavy-matrices`, off by default while measured. Adapter-only
implementation in `dk_preamp/melange_adapter.rs`; generated code unchanged.

The Heavy adapter runs the generated preamp for main audio and again for its
zero-input shadow. Both receive identical LDR updates. The generated
`rebuild_matrices` at `gen_preamp.rs:4102` depends only on working G/C matrices
and internal sample rate. It rewrites eleven coefficient arrays and invalidates
the chord cache. Inverse failure leaves the old inverse/derived arrays intact.

Candidate requires both instances dirty, bit-identical working G/C and sample
rate, and bit-identical prior inverse/derived arrays (S, K, S_NI and BE variants).
It rebuilds main once before processing and copies only the exact generated
write set to shadow: A, A_neg, A_be, A_neg_be, A_neg_sub, S, K, S_NI, S_be,
K_be, S_NI_be. It clears shadow's dirty flag and invalidates shadow's chord LU
cache, exactly as the skipped rebuild would. It copies no node voltage,
nonlinear current, input history, predictor history, RNG, noise cache, solver
iteration state, diagnostic counters or LU factors. Unused substep inverse
arrays are not written by generated rebuild and are not copied.

Checking prior inverse equality is necessary for failed inversion: merely
matching current G/C would not guarantee equal retained fallback inverses after
different histories. Mismatched configuration/inverses or differing dirty flags
fall back to the original two independent rebuilds. Main audio and shadow
still each run their complete original nonlinear solver every sample. This
candidate does not freeze or remove the shadow solve.

The adapter exposes one internal const-specialized processing method: false is
the original path, true enables sharing. Focused tests passed:

- `shared_rebuild_preserves_heavy_output_state_noise_and_reset`: 6,144 samples
  across 44.1/88.2/96 kHz, noise off/on, constant and continuously varying LDR,
  reset, sine input. Output, both sets of node/current/predictor histories, NR
  iteration counts and reset diagnostics match bitwise.
- `shared_rebuild_preserves_failed_inverse_and_rejects_mismatched_state`: forced
  singular G/C keeps original inverse fallback arrays, clears the same dirty/
  chord-valid flags, and declines reuse for unequal preserved inverses or G.

Checked and tested with `--no-default-features --features
melange-preamp,cpu-study-heavy-matrices,cpu-study-tremolo-zero`. The existing
native tanh helper is unused in a Heavy-only build (warning, not a failure).
No CPU timing was performed; parent schedules full-engine pre/post and timing.
